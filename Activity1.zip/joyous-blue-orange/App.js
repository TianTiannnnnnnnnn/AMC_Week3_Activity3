import React from 'react';
import {StyleSheet, TextInput} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
  const [name, onChangeText] = React.useState('Name:');
  const [age, onChangeAge] = React.useState('Age:');
  const [address, onChangeAddress] = React.useState('Address:');
  const [school, onChangeschool] = React.useState('School:');
  const [course, onChangecourse] = React.useState('Course:');
  const [email, onChangeemail] = React.useState('Email:');
  const [contact, onChangecontact] = React.useState('Contact:');
  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText}
          value={name}
        />
        <TextInput
          style={styles.input}
          onChangeText={onChangeAge}
          value={age}
        />
        <TextInput
          style={styles.input}
          placeholder="Address:"
        />
        <TextInput
          style={styles.input}
          placeholder="School:"
        />
        <TextInput
          style={styles.input}
          placeholder="Course:"
        />
        <TextInput
          style={styles.input}
          placeholder="Email:"
        />
        <TextInput
          style={styles.input}
          placeholder="Contact No:"
          keyboardType="numeric"
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});

export default TextInputExample;